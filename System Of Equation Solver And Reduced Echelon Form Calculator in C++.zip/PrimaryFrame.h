#pragma once
#include <wx/wx.h>
#include <wx/stc/stc.h>
#include <vector>

class PrimaryFrame : public wxFrame {
public:
	PrimaryFrame(const wxString& title);
	void OnChoice(wxCommandEvent& event, wxPanel* panel, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxButton* button);
	void reduce_to_echelon_random(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxButton* button);
	void reduce_to_echelon_custom(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxButton* button);
	void print_matrix_original(const std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* box);
	void print_matrix_reduced(const std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* box);
	void swap_rows(std::vector<std::vector<double>>& matrix, int i, int j);
	void row_reduce(std::vector<std::vector<double>>& matrix);
	void takeInput(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget1);
	void row_reduce_and_print(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget2);
	void OnButtonPress(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget2);
	void InputText(std::vector<std::vector<double>>& matrix, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxPanel* panel);
};