#pragma once
#include <wx/wx.h>

class MainEntry : public wxApp
{
public:
	bool OnInit();
};

