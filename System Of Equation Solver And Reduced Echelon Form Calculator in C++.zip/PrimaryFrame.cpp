#include "PrimaryFrame.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <string>
#include <sstream>
#include <wx/wx.h>
#include <wx/tokenzr.h>
#include <wx/stc/stc.h>

using namespace std;

const double EPSILON = 1e-10;

PrimaryFrame::PrimaryFrame(const wxString& title) : wxFrame(nullptr, wxID_ANY, title)
{
    // create a scrolled window to contain the panel
    wxScrolledWindow* scrolledWindow = new wxScrolledWindow(this, wxID_ANY);
    scrolledWindow->SetScrollbars(20, 20, 50, 50, 0, 0, false);
    scrolledWindow->SetVirtualSize(3000, 3000);
    scrolledWindow->SetSizer(new wxBoxSizer(wxVERTICAL));
    

    // create a scrolled window for the panel
    wxPanel* m_panel = new wxPanel(scrolledWindow, wxID_ANY);

    scrolledWindow->GetSizer()->Add(m_panel, 1, wxEXPAND, 0);

    // create output box two for original matrix
    wxStyledTextCtrl* m_outputBox1 = new wxStyledTextCtrl(m_panel, wxID_ANY, wxPoint(50, 150), wxSize(1260, 830));
    m_outputBox1->SetTabWidth(4);
    m_outputBox1->StyleSetFont(wxSTC_STYLE_DEFAULT, wxFont(10, wxFONTFAMILY_TELETYPE, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL));
    m_outputBox1->SetLexer(wxSTC_LEX_NULL);
    m_outputBox1->SetUseVerticalScrollBar(false); // Disable the vertical scroll bar
    m_outputBox1->SetUseHorizontalScrollBar(false); // Disable the horizontal scroll bar

    // create a button to reduce
    wxButton* button = new wxButton(m_panel, wxID_ANY, wxString("Reduce"), wxPoint(100, 10), wxDefaultSize);

    // create output box two for reduced matrix
    wxStyledTextCtrl* m_outputBox2 = new wxStyledTextCtrl(m_panel, wxID_ANY, wxPoint(50, 1400), wxSize(1260, 830));
    m_outputBox2->SetWrapMode(wxSTC_WRAP_NONE);
    m_outputBox2->SetTabWidth(4);
    m_outputBox2->StyleSetFont(wxSTC_STYLE_DEFAULT, wxFont(10, wxFONTFAMILY_TELETYPE, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL));
    m_outputBox2->SetLexer(wxSTC_LEX_NULL);
    m_outputBox2->SetUseVerticalScrollBar(false); // Disable the vertical scroll bar
    m_outputBox2->SetUseHorizontalScrollBar(true); // Disable the horizontal scroll bar

    // create the choice control inside the panel
    wxArrayString myStrings;
    myStrings.Add("Random");
    myStrings.Add("Custom");

    wxChoice* m_choices = new wxChoice(m_panel, wxID_ANY, wxDefaultPosition, wxDefaultSize, myStrings);
    m_choices->SetSelection(0);
    m_choices->Bind(wxEVT_CHOICE, std::bind(&PrimaryFrame::OnChoice, this, std::placeholders::_1, m_panel, m_outputBox1, m_outputBox2, button));

    // set the sizer for the panel
    wxBoxSizer* panelSizer = new wxBoxSizer(wxVERTICAL);
    panelSizer->Add(m_choices, 0, wxALL, 10);
    panelSizer->Add(m_outputBox1, 0, wxALL, 10);
    panelSizer->Add(m_outputBox2, 0, wxALL, 10);

    m_panel->SetSizer(panelSizer);
    panelSizer->SetSizeHints(m_panel);



    // set the main sizer for the frame
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
    mainSizer->Add(scrolledWindow, 1, wxEXPAND, 0);
    SetSizerAndFit(mainSizer);
}

void PrimaryFrame::OnChoice(wxCommandEvent& event, wxPanel* panel, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxButton* button)
{
	int index = event.GetSelection();
    const int TOTAL = 50;
    vector<vector<double>> matrix;
    widget1->ClearAll();
    widget2->ClearAll();
    //random
	if (index == 0)
	{
        srand(time(0));
        const int MAXVAL = 50;  
        
        for (int i = 0; i < TOTAL; i++)
        {
            vector<double> sub;
            for (int j = 0; j < TOTAL + 1; j++)
            {
                sub.push_back(double(rand() % 50));
            }
            matrix.push_back(sub);
        }

        reduce_to_echelon_random(matrix, panel, widget1, widget2, button);
	}

    //custom
	else if (index == 1)
	{
        reduce_to_echelon_custom(matrix, panel, widget1, widget2, button);
	}
}

void PrimaryFrame::reduce_to_echelon_random(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxButton* button)
{
    print_matrix_original(matrix, panel, widget1);

    button->Bind(wxEVT_BUTTON, std::bind(&PrimaryFrame::OnButtonPress, this, matrix, panel, widget2));
}

void PrimaryFrame::reduce_to_echelon_custom(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxButton* button)
{
    widget1->SetEditable(true);
    widget1->SetReadOnly(false);
    button->Bind(wxEVT_BUTTON, std::bind(&PrimaryFrame::InputText, this, matrix, widget1, widget2, panel));
}

void PrimaryFrame::print_matrix_original(const vector<vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* box)
{
    int max_width = 0;

    // stringstream allows us to use 'cout' statements to insert into a string-like entity
    stringstream output;

    // find the maximum element width in the matrix
    for (const auto& row : matrix) {
        for (const auto& elem : row) {
            int width = to_string((int)elem).length() + 1; // add 1 for the decimal point
            if (width > max_width) {
                max_width = width;
            }
        }
    }

    // create a new wxStyledTextCtrl control

    // set the tab width to 4 spaces
    box->SetTabWidth(4);

    // set the font of the control
    wxFont font(10, wxFONTFAMILY_TELETYPE, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
    box->StyleSetFont(wxSTC_STYLE_DEFAULT, font);

    // print the matrix with adjusted tab width
    for (const auto& row : matrix) {
        for (const auto& elem : row) {
            if (fabs(elem) < EPSILON) {
                output << setw(max_width) << "0";
            }
            else {
                output << ((std::signbit(elem)) ? "-" : "") << setprecision(5) << setw(max_width) << fabs(elem);
            }
        }
        output << "\n";
    }

    // set the value of the output box to the matrix string
    wxString text(output.str());
    box->SetText(text);

    // set the language to plain text
    box->SetLexer(wxSTC_LEX_NULL);
}




void PrimaryFrame::print_matrix_reduced(const vector<vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* box)
{
    // determine maximum element width in the matrix, accounting for floating point values
    int max_width = 0;
    stringstream output;

    for (const auto& row : matrix) {
        for (const auto& elem : row) {
            stringstream ss;
            ss << fixed << setprecision(2) << elem;
            int width = ss.str().length() + 1;
            if (width > max_width) {
                max_width = width;
            }
        }
    }

    // increase maximum width by 1 to account for the negative sign
    max_width++;

    // set the tab width to 4 spaces
    box->SetTabWidth(4);

    // set the font of the control
    wxFont font(10, wxFONTFAMILY_TELETYPE, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
    box->StyleSetFont(wxSTC_STYLE_DEFAULT, font);

    // print the matrix with adjusted tab width
    for (const auto& row : matrix) {
        for (const auto& elem : row) {
            if (fabs(elem) < EPSILON) {
                output << setw(3) << "0" << " ";
            }
            else if (elem == floor(elem)) {
                // print as integer
                output << setw(3) << static_cast<int>(elem) << " ";
            }
            else {
                // print with 2 decimal places
                output << setw(3) << fixed << setprecision(2) << elem << " ";
            }
        }
        output << "\n";
    }




    // set the value of the output box to the matrix string
    wxString text(output.str());
    box->SetText(text);

    // set the language to plain text
    box->SetLexer(wxSTC_LEX_NULL);
}


void PrimaryFrame::swap_rows(vector<vector<double>>& matrix, int i, int j) {
    if (i != j) {
        swap(matrix[i], matrix[j]);
    }
}

void PrimaryFrame::row_reduce(vector<vector<double>>& matrix) {
    int n = matrix.size(); // number of rows in the matrix
    int m = matrix[0].size(); // number of columns in the matrix

    int lead = 0; // current column being reduced

    for (int r = 0; r < n; r++) {
        if (lead >= m) {
            // we have reduced all columns, so we are done
            return;
        }

        // find the row with the largest absolute value in the current column
        int i = r;
        while (abs(matrix[i][lead]) < EPSILON) {
            i++;
            if (i == n) {
                i = r;
                lead++;
                if (lead == m) {
                    // we have reduced all columns, so we are done
                    return;
                }
            }
        }

        // swap the rows so that the largest element is in the pivot position
        swap_rows(matrix, i, r);

        // divide the pivot row by the pivot element to make it 1
        double pivot = matrix[r][lead];
        for (int j = 0; j < m; j++) {
            matrix[r][j] /= pivot;
        }

        // use row operations to make all other elements in the current column 0
        for (int j = 0; j < n; j++) {
            if (j != r) {
                double factor = matrix[j][lead];
                for (int k = 0; k < m; k++) {
                    matrix[j][k] -= factor * matrix[r][k];
                }
            }
        }

        lead++;
    }
}

void PrimaryFrame::takeInput(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget1)
{

}

void PrimaryFrame::OnButtonPress(std::vector<std::vector<double>>& matrix, wxPanel* panel, wxStyledTextCtrl* widget2)
{
    row_reduce(matrix);
    widget2->ClearAll();
    print_matrix_reduced(matrix, panel, widget2);
}

void PrimaryFrame::InputText(std::vector<std::vector<double>>& matrix, wxStyledTextCtrl* widget1, wxStyledTextCtrl* widget2, wxPanel* panel)
{
    wxString text = widget1->GetText();

    // Split the text into rows based on the newline escape character
    std::vector<std::string> rows;
    wxStringTokenizer tokenizer(text, "\n");
    while (tokenizer.HasMoreTokens()) {
        rows.push_back(tokenizer.NextToken().ToStdString());
    }

    // Split each row into values based on the comma separator
    for (auto& row : rows) {
        std::vector<double> values;
        wxStringTokenizer tokenizer(row, ",");
        while (tokenizer.HasMoreTokens()) {
            double value;
            tokenizer.NextToken().ToDouble(&value);
            values.push_back(value);
        }
        matrix.push_back(values);
    }

    row_reduce(matrix);
    print_matrix_reduced(matrix, panel, widget2);
}