#include "MainEntry.h"
#include <wx/wx.h>
#include "PrimaryFrame.h"

wxIMPLEMENT_APP(MainEntry);

bool MainEntry::OnInit()
{
	PrimaryFrame* primaryFrame = new PrimaryFrame("This is the title");
	primaryFrame->Show();
	primaryFrame->SetClientSize(1800, 1000);
	primaryFrame->Center(); 
	return true;
}
