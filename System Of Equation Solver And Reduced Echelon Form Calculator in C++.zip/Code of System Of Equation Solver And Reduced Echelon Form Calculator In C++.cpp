#include <iostream>
#include <vector>
#include <random>
#include <iomanip>
#include <sstream>
#include <algorithm>

// Number of variables and equations
const int numVariables = 50;
const int numEquations = 50;

// Generate random coefficients and constants for the system
void generateSystem(std::vector<std::vector<double>>& coefficients, std::vector<double>& constants) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(0, 100);

    coefficients.resize(numEquations, std::vector<double>(numVariables, 0.0));
    constants.resize(numEquations, 0.0);

    for (int i = 0; i < numEquations; i++) {
        for (int j = 0; j < numVariables; j++) {
            coefficients[i][j] = static_cast<double>(dist(gen));
        }
        constants[i] = static_cast<double>(dist(gen));
    }
}

// Format the double value as a string
std::string formatDouble(double value) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(2) << value;
    std::string formatted = oss.str();

    // Remove trailing zeros after the decimal point
    if (formatted.find('.') != std::string::npos) {
        formatted.erase(formatted.find_last_not_of('0') + 1, std::string::npos);
    }

    // Remove the decimal point if there are no non-zero digits after it
    if (formatted.back() == '.') {
        formatted.pop_back();
    }

    return formatted;
}

// Calculate the column widths based on the matrix elements
std::vector<int> calculateColumnWidths(const std::vector<std::vector<double>>& matrix) {
    std::vector<int> columnWidths(matrix[0].size(), 0);

    for (const auto& row : matrix) {
        for (size_t j = 0; j < row.size(); j++) {
            std::string formatted = formatDouble(row[j]);
            columnWidths[j] = std::max(columnWidths[j], static_cast<int>(formatted.length()));
        }
    }

    return columnWidths;
}

// Display the original system of equations in AX = B format
void displaySystem(const std::vector<std::vector<double>>& coefficients, const std::vector<double>& constants, int numVariables, int numEquations) {
    std::cout << "Original System: [A] [X] = [B]" << std::endl << std::endl;

    // Calculate column widths
    std::vector<int> columnWidthsA = calculateColumnWidths(coefficients);
    std::vector<int> columnWidthsX(numVariables, 1);  // Fixed width for variable names
    std::vector<int> columnWidthsB = calculateColumnWidths({ constants });

    for (int i = 0; i < numEquations; i++) {
        std::ostringstream ossA;
        for (int j = 0; j < numVariables; j++) {
            ossA << std::setw(columnWidthsA[j]) << formatDouble(coefficients[i][j]) << " ";
        }

        std::ostringstream ossX;
        ossX << "x" << (i + 1);

        std::ostringstream ossB;
        ossB << std::setw(columnWidthsB[0]) << formatDouble(constants[i]);

        std::cout << "[" << ossA.str() << "] [" << ossX.str() << "] = [" << ossB.str() << "]" << std::endl;
    }

    std::cout << std::endl;
}

// Display the augmented matrix [A b]
void displayAugmentedMatrix(const std::vector<std::vector<double>>& coefficients, const std::vector<double>& constants, int numVariables, int numEquations) {
    std::cout << "Augmented Matrix: [A|b]" << std::endl << std::endl;

    // Calculate column widths
    std::vector<int> columnWidthsA = calculateColumnWidths(coefficients);
    std::vector<int> columnWidthsB = calculateColumnWidths({ constants });

    for (int i = 0; i < numEquations; i++) {
        std::ostringstream ossA;
        for (int j = 0; j < numVariables; j++) {
            ossA << std::setw(columnWidthsA[j]) << formatDouble(coefficients[i][j]) << " ";
        }

        std::ostringstream ossB;
        ossB << std::setw(columnWidthsB[0]) << formatDouble(constants[i]);

        std::cout << "[" << ossA.str() << "| " << ossB.str() << "]" << std::endl;
    }

    std::cout << std::endl;
}

void gaussianElimination(std::vector<std::vector<double>>& coefficients, std::vector<double>& constants, int numVariables, int numEquations) {
    for (int i = 0; i < numEquations; i++) {
        if (i >= coefficients[i].size()) {
            std::cout << "Error: Insufficient coefficients in equation " << i + 1 << ". Aborting." << std::endl;
            return;
        }

        // Find the pivot element
        double pivot = coefficients[i][i];

        // Make the pivot element 1
        for (int j = i; j < numVariables; j++) {
            if (j >= coefficients[i].size()) {
                std::cout << "Error: Insufficient coefficients in equation " << i + 1 << ". Aborting." << std::endl;
                return;
            }
            coefficients[i][j] /= pivot;
        }
        constants[i] /= pivot;

        // Eliminate other variables
        for (int j = 0; j < numEquations; j++) {
            if (j != i) {
                if (i >= coefficients[j].size()) {
                    std::cout << "Error: Insufficient coefficients in equation " << j + 1 << ". Aborting." << std::endl;
                    return;
                }
                double factor = coefficients[j][i];
                for (int k = i; k < numVariables; k++) {
                    if (k >= coefficients[j].size()) {
                        std::cout << "Error: Insufficient coefficients in equation " << j + 1 << ". Aborting." << std::endl;
                        return;
                    }
                    coefficients[j][k] -= factor * coefficients[i][k];
                }
                constants[j] -= factor * constants[i];
            }
        }
    }
}


// Display the reduced echelon augmented matrix
void displayReducedEchelonMatrix(const std::vector<std::vector<double>>& coefficients, const std::vector<double>& constants, int numVariables, int numEquations) {
    std::cout << "Reduced Echelon Matrix: [A|b]" << std::endl << std::endl;

    // Calculate column widths
    std::vector<int> columnWidthsA = calculateColumnWidths(coefficients);
    std::vector<int> columnWidthsB = calculateColumnWidths({ constants });

    for (int i = 0; i < numEquations; i++) {
        std::ostringstream ossA;
        for (int j = 0; j < numVariables; j++) {
            ossA << std::setw(columnWidthsA[j]) << formatDouble(coefficients[i][j]) << " ";
        }

        std::ostringstream ossB;
        ossB << std::setw(columnWidthsB[0]) << formatDouble(constants[i]);

        std::cout << "[" << ossA.str() << "| " << ossB.str() << "]" << std::endl;
    }

    std::cout << std::endl;
}

// Display the final equations and values of variables
void displayFinalEquations(const std::vector<std::vector<double>>& coefficients, const std::vector<double>& constants, int numVariables, int numEquations) {
    std::cout << "Final Equations:" << std::endl << std::endl;

    // Calculate column widths
    std::vector<int> columnWidthsX(numVariables, 1);  // Fixed width for variable names
    std::vector<int> columnWidthsB = calculateColumnWidths({ constants });

    for (int i = 0; i < numEquations; i++) {
        std::ostringstream oss;
        oss << "Equation " << (i + 1) << ": ";
        bool hasBaseVariable = false;
        bool hasFreeVariable = false;
        bool isZeroRow = true;

        for (int j = 0; j < numVariables; j++) {
            if (coefficients[i][j] != 0.0) {
                isZeroRow = false;

                if (!hasBaseVariable) {
                    hasBaseVariable = true;
                    if (std::abs(coefficients[i][j]) == 1.0) {
                        oss << "x" << (j + 1);
                    }
                    else {
                        oss << std::setw(columnWidthsX[j]) << formatDouble(std::abs(coefficients[i][j])) << " * x" << (j + 1);
                    }
                }
                else {
                    hasFreeVariable = true;
                    if (coefficients[i][j] < 0.0) {
                        oss << " - ";
                    }
                    else {
                        oss << " + ";
                    }
                    oss << std::setw(columnWidthsX[j]) << formatDouble(std::abs(coefficients[i][j])) << " * x" << (j + 1);
                }
            }
        }

        if (isZeroRow) {
            std::cout << "Equation " << (i + 1) << ": (No Equation)" << std::endl;
        }
        else {
            if (!hasBaseVariable) {
                oss << "0.00";
            }
            oss << " = " << std::setw(columnWidthsB[0]) << formatDouble(constants[i]);
            std::cout << oss.str() << std::endl;

            if (!hasFreeVariable) {
                std::cout << "  (No Free Variables)" << std::endl;
            }
        }
    }
}

void UserDefinedSystem() {
    std::vector<std::vector<double>> coefficients;
    std::vector<double> constants;

    std::cout << "Enter the values for the system of equations:" << std::endl;
    std::cout << "(Values separated by spaces, press Enter for a new row, and press Enter twice to finish)" << std::endl;

    std::string line;
    size_t maxRowSize = 0;
    while (std::getline(std::cin, line)) {
        if (line.empty()) {
            if (!coefficients.empty()) {
                break;
            }
            else {
                std::cout << "Error: Insufficient input. Aborting." << std::endl;
                return;
            }
        }

        std::vector<double> row;
        std::istringstream iss(line);
        double value;
        while (iss >> value) {
            row.push_back(value);
        }
        maxRowSize = std::max(maxRowSize, row.size());
        coefficients.push_back(row);
    }

    // padding with 0's to make all rows the same length
    for (auto& row : coefficients) {
        while (row.size() < maxRowSize) {
            row.push_back(0.0);
        }
    }

    // move the last element of each row to constants and remove it from coefficients
    for (auto& row : coefficients) {
        constants.push_back(row.back());
        row.pop_back();
    }

    //for (int i = 0; i < coefficients.size(); i++)
    //{
    //    for (int j = 0; j < coefficients[0].size(); j++)
    //    {
    //        std::cout << coefficients[i][j] << ' ';
    //    }
    //    std::cout << std::endl;
    //}
    //std::cout << std::endl;
    //for (int j = 0; j < constants.size(); j++)
    //{
    //    std::cout << constants[j] << ' ';
    //}

    //std::cout << std::endl;

    int numVariables = coefficients[0].size();
    int numEquations = coefficients.size();
    displaySystem(coefficients, constants, numVariables, numEquations);
    displayAugmentedMatrix(coefficients, constants, numVariables, numEquations);
    gaussianElimination(coefficients, constants, numVariables, numEquations);
    displayReducedEchelonMatrix(coefficients, constants, numVariables, numEquations);
    displayFinalEquations(coefficients, constants, numVariables, numEquations);
}




void RandomlyGenerated () {
    std::vector<std::vector<double>> coefficients;
    std::vector<double> constants;

    // Step 1: Generate the system of equations
    generateSystem(coefficients, constants);

    // Step 2: Display the original system of equations
    displaySystem(coefficients, constants, 50, 50);

    // Step 3: Display the augmented matrix [A b]
    displayAugmentedMatrix(coefficients, constants, 50, 50);

    // Step 4: Perform Gaussian elimination
    gaussianElimination(coefficients, constants, 50, 50);

    // Step 5: Display the reduced echelon augmented matrix
    displayReducedEchelonMatrix(coefficients, constants, 50, 50);

    // Step 6: Display the final equations and values of variables
    displayFinalEquations(coefficients, constants, 50, 50);
}

int main() {
    std::cout << "Select an option:" << std::endl;
    std::cout << "1. Randomly Generated System of Equations" << std::endl;
    std::cout << "2. User Generated System of Equations" << std::endl;
    std::cout << "Enter your choice (1 or 2): ";

    int choice;
    std::cin >> choice;

    // Discard the newline character left in the buffer
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    if (choice == 1) {
        RandomlyGenerated();
    }
    else if (choice == 2) {
        UserDefinedSystem();
    }
    else {
        std::cout << "Invalid choice. Exiting the program." << std::endl;
    }

    return 0;
}
